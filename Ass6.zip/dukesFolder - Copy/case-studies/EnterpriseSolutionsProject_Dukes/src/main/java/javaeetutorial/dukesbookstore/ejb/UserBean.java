/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaeetutorial.dukesbookstore.ejb;

import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import javaeetutorial.dukesbookstore.entity.Group;
import javaeetutorial.dukesbookstore.entity.User;
import javaeetutorial.dukesbookstore.utils.AuthenticationUtils;


@Stateless
public class UserBean {
	
	@PersistenceContext(unitName="DukesBooks")
	private EntityManager em;
	
	public User createUser(User user) {
		try {
			user.setPassword(AuthenticationUtils.encodeSHA256(user.getPassword()));
		} catch (Exception e) {
			Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, e);
			e.printStackTrace();
		}

		Group group = new Group();
		group.setEmail(user.getEmail());
		group.setGroupname(Group.USERS_GROUP);

		em.persist(user);
		em.persist(group);
		
		return user;
	}

	public User findUserById(String id) {
                TypedQuery<User> query = em.createNamedQuery("findUserByEmail", User.class);
		//TypedQuery<User> query = em.createQuery("findUserById", User.class);
		query.setParameter("email", id);
		User user = null;
		try {
			user = query.getSingleResult();
		} catch (Exception e) {
			// getSingleResult throws NoResultException in case there is no user in DB
			// ignore exception and return NULL for user instead
		}
		return user;
	}
        
        public String userFullNameById(Integer id) {
                TypedQuery<User> query = em.createNamedQuery("findUserById", User.class);
		//TypedQuery<User> query = em.createQuery("findUserById", User.class);
		query.setParameter("userId", id);
		User user = null;
		try {
			user = query.getSingleResult();
		} catch (Exception e) {
			// getSingleResult throws NoResultException in case there is no user in DB
			// ignore exception and return NULL for user instead
		}
		return user.getFisrtName() + " " + user.getLastName();
	}
        
}
