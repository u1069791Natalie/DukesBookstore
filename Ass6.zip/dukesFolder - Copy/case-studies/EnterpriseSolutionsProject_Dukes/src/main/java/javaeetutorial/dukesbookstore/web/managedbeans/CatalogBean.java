/**
 * Copyright (c) 2014 Oracle and/or its affiliates. All rights reserved.
 *
 * You may not modify, use, reproduce, or distribute this software except in
 * compliance with  the terms of the License at:
 * https://github.com/javaee/tutorial-examples/LICENSE.txt
 */
package javaeetutorial.dukesbookstore.web.managedbeans;

import java.io.Serializable;
import java.util.List;
import javaeetutorial.dukesbookstore.entity.Book;
import javaeetutorial.dukesbookstore.entity.UserItem;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import javax.servlet.ServletException;

/**
 * <p>Backing bean for the <code>/bookcatalog.xhtml</code> page.</p>
 */
@Named("catalog")
@SessionScoped
public class CatalogBean extends AbstractBean implements Serializable {

    private static final long serialVersionUID = -3594317405246398714L;
    private int totalBooks = 0;

    /**
     * @return the currently selected <code>Book</code> instance from the 
     * user request
     */
    protected Book book() {
        Book book;
        book = (Book) context().getExternalContext()
           .getRequestMap().get("book");

        return (book);
    }
    
    protected UserItem userItem() {
        UserItem userItem;
        userItem = (UserItem) context().getExternalContext()
           .getRequestMap().get("item");

        return (userItem);
    }

    /**
     * <p>Add the selected item to our shopping cart.</p>
     * @return the navigation page
     */
    public String addItem() {
        UserItem item = userItem();
        cart.add(item.getUserSaleItemId(), item);
        message(null, "ConfirmAdd", new Object[]{item.getTitle()});

        return ("bookcatalog");
    }
    
    public String trade() {
        context().getExternalContext().getSessionMap().put("selected", userItem());
        return ("/user/trade");
    }

    public String add() {
        Book book = book();
        cart.add(book.getBookId(), book);
        message(null, "ConfirmAdd", new Object[]{book.getTitle()});

        return ("bookcatalog");
    }
    
    /**
     * <p>Show the details page for the current book.</p>
     * @return the navigation page
     */
    public String details() {
        context().getExternalContext().getSessionMap().put("selected", book());
        return ("bookdetails");
    }

    public String itemDetails() {
        context().getExternalContext().getSessionMap().put("selected", userItem());
        return ("userItemDetails");
    }
    
    public int getTotalBooks() {
        totalBooks = cart.getNumberOfItems();
        return totalBooks;
    }

    public void setTotalBooks(int totalBooks) {
        this.totalBooks = totalBooks;
    }

    public int getBookQuantity() {
        int bookQuantity = 0;
        Book book = book();
        UserItem userItem = userItem();
        
        if (book == null && userItem == null ) {
            return bookQuantity;
        }

        List<ShoppingCartItem> results = cart.getItems();
        for (ShoppingCartItem item : results) {
            if (item.getItem() instanceof Book && book != null) {
                Book bd = (Book) item.getItem();
                //if ((bd.getBookId()).equals(book.getBookId())) {
                if (bd.getBookId() == book.getBookId()) {
                    bookQuantity = item.getQuantity();
                    break;
                }
            } else if (item.getItem() instanceof UserItem && userItem != null) {
                UserItem bd = (UserItem) item.getItem();
                if (bd.getUserSaleItemId() == userItem.getUserSaleItemId()) {
                    bookQuantity = item.getQuantity();
                    break;
                }
            }
        }
        return bookQuantity;
    }
    
    public int getLoggedIn() { 
        try {
            Integer userId = loggedInUser.getAuthenticatedUserId();		
            return userId;
        } catch (NullPointerException e) {
            return 0;	
	}
    }
    
    
    /*
    public int getBookQuantity2() {
        int bookQuantity = 0;
        Book book = book();

        if (book == null) {
            return bookQuantity;
        }

        List<ShoppingCartItem> results = cart.getItems();
        for (ShoppingCartItem item : results) {
            Book bd = (Book) item.getItem();
            if (bd.getBookId() == book.getBookId()) {
                bookQuantity = item.getQuantity();
                break;
            }
        }

        return bookQuantity;
    }
    
    public int getItemQuantity() {
        int bookQuantity = 0;
        UserItem userItem = userItem();
        
        if (userItem == null ) {
            return bookQuantity;
        }

        
        List<ShoppingCartItem> results = cart.getItems();
        for (ShoppingCartItem item : results) {
            UserItem bd = (UserItem) item.getItem();
            if (bd.getUserSaleItemId() == userItem.getUserSaleItemId()) {
                    bookQuantity = item.getQuantity();
                    break;
            }
        }

        return bookQuantity;
    }
    */


    
}
