/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaeetutorial.dukesbookstore.web.managedbeans;



import java.io.Serializable;
import java.security.Principal;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javaeetutorial.dukesbookstore.ejb.UserBean;
import javaeetutorial.dukesbookstore.entity.User;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
//import javax.faces.bean.ManagedBean;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
//import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

//@ManagedBean
@Named
@SessionScoped
public class LoginBean extends AbstractBean implements Serializable {

	private static final long serialVersionUID = 3254181235309041386L;

	private static Logger log = Logger.getLogger(LoginBean.class.getName());

	@EJB
	private UserBean userEJB;

	private String email;
	private String password;
	private User user;
        private String message;

	public String login() {
		FacesContext context = FacesContext.getCurrentInstance();
		HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getRequest();
                //HttpServletRequest request = ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
                String fromUrl = request.getHeader("referer");
                if (fromUrl.contains("bookcashier")) {
                    fromUrl = "/user/bookcashier?faces-redirect=true";
                } else {
                    fromUrl = "/index";
                }
                
		try {
			request.login(email, password);
                        this.setMessage(null);
		} catch (ServletException e) {
			context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Login failed!", null));
                        this.setEmail(null);
                        this.setPassword(null);
                        this.setMessage("Username or Password incorrect");
			return "signin";
		}

		Principal principal = request.getUserPrincipal();

		this.user = userEJB.findUserById(principal.getName());
                
                request.getSession().setAttribute("loggedInUser", this.user.getFisrtName() + " " + this.user.getLastName());
                
		log.info("Authentication done for user: " + principal.getName());

		ExternalContext externalContext = FacesContext.getCurrentInstance().getExternalContext();
		Map<String, Object> sessionMap = externalContext.getSessionMap();
		sessionMap.put("User", user);

		if (request.isUserInRole("users")) {
			return fromUrl;
		} else {
			return "Loginpage";
		}
	}

	public String logout() {
		FacesContext context = FacesContext.getCurrentInstance();
		HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getRequest();

		try {
			this.user = null;
			request.logout();
			// clear the session
			((HttpSession) context.getExternalContext().getSession(false)).invalidate();
		} catch (ServletException e) {
			log.log(Level.SEVERE, "Failed to logout user!", e);
		}

		return "/index?faces-redirect=true";
	}

	public User getAuthenticatedUser() {
		return user;
	}
        
        public Integer getAuthenticatedUserId() {
            return user.getUserId();
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
        
        public String getFullName() {
		return this.user.getFisrtName() + ' ' + this.user.getLastName();
	}
        
        public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
}
