/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaeetutorial.dukesbookstore.ejb;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javaeetutorial.dukesbookstore.entity.Trade;
import javaeetutorial.dukesbookstore.entity.UserItem;
import javaeetutorial.dukesbookstore.exception.BookNotFoundException;
import javaeetutorial.dukesbookstore.exception.BooksNotFoundException;
import javax.ejb.Stateless;
import javax.faces.FacesException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;


@Stateless
public class UserItemBean {
	
	@PersistenceContext(unitName="DukesBooks")
	private EntityManager em;
	
	public Integer createUserItem(UserItem userItem) {
		em.persist(userItem);	
		return getLastId(userItem.getUserId());
	}
        
        public Trade createTradeItem(Trade tradeItem) {
		em.persist(tradeItem);	
		return tradeItem;
	}

        public List<UserItem> getUserItems() throws BooksNotFoundException {
            try {
                return (List<UserItem>) em.createNamedQuery("findUserItems").getResultList();
            } catch (Exception ex) {
                throw new BooksNotFoundException(
                        "Could not get books: " + ex.getMessage());
            }
        }
        
        public List<UserItem> getUserItems(String search) throws BooksNotFoundException {
            try {
                return (List<UserItem>) em.createNamedQuery("searchItems")
                        .setParameter("search", "%" + search.toLowerCase() + "%")
                        .getResultList();
            } catch (Exception ex) {
                throw new BooksNotFoundException(
                        "Could not get books: " + ex.getMessage());
            }
        }
        
        public UserItem getUserItem(Integer itemId) throws BookNotFoundException {
        try {
                UserItem requestedItem = em.find(UserItem.class, itemId);
                if (requestedItem == null) {
                    throw new BookNotFoundException("Couldn't find book: " + itemId);
                }
                return requestedItem;
            } catch (BookNotFoundException e) {
                throw new FacesException("Could not convert id: " + e);
            }
        }
            
        public List<UserItem> getUserItemsById(Integer userId) throws BooksNotFoundException {
            try {
                return (List<UserItem>) em.createNamedQuery("getItemsById")
                        .setParameter("userId", userId)
                        .getResultList();
            } catch (Exception ex) {
                throw new BooksNotFoundException(
                        "Could not get books: " + ex.getMessage());
            }
        }
        
        public Trade getTradeById(Integer itemId) throws BooksNotFoundException {
            TypedQuery<Trade> query = em.createNamedQuery("getTradeById", Trade.class);
		query.setParameter("itemId", itemId);
		Trade item = null;
                //Integer id = null;
		try {
			item = query.getSingleResult();
                        //id = item.getTradeId();
		} catch (Exception e) {
			return null;
		}
		return item;
        }
        
        public synchronized void markItemDeleted(UserItem userItem) {
            userItem.setDeleted(true);
            em.merge(userItem);
        }
    
        public Integer getLastId(Integer userId) {
                TypedQuery<UserItem> query = em.createNamedQuery("getLastItemId", UserItem.class);
		query.setParameter("userId", userId);
		UserItem item = null;
                Integer id = null;
		try {
			item = query.getSingleResult();
                        id = item.getUserSaleItemId();
		} catch (Exception e) {
			// getSingleResult throws NoResultException in case there is no user in DB
			// ignore exception and return NULL for user instead
		}
		return id;
        }
        
        public synchronized void tradeItem(UserItem tradeItem, UserItem item) {
            Integer id = tradeItem.getUserSaleItemId();
            try {
		Trade trade = getTradeById(id);
                Date date = new Date();
                //if (trade.getOfferTimeKey() == null) {
                //    trade.setOffer(date, item.getUserId(), item.getUserSaleItemId());
                //    em.merge(trade);
                //} else {
                Trade newTrade = new Trade(trade.getTradeId(), trade.getOwnerId(), trade.getStatus(), 
                        date, item.getUserId(), item.getUserSaleItemId());
                em.persist(newTrade);
                //}
                item.setSold(2);
                em.merge(item);
            } catch (Exception e) {
			// getSingleResult throws NoResultException in case there is no user in DB
			// ignore exception and return NULL for user instead
            }
        }
        
        public List<UserItem> getTradingItemsById(Integer itemId, Integer userId) throws BooksNotFoundException {
            List<Trade> query = em.createNamedQuery("getTradeItemById", Trade.class)
                    .setParameter("itemId", itemId)
                    .setParameter("userId", userId)
                    .getResultList();
                    ;
            List<UserItem> tradingItems = new ArrayList();
            try {
                for (Trade item : query) {
                    tradingItems.add(getUserItem(item.getItemId()));
                }
            } catch (Exception e) {
			// getSingleResult throws NoResultException in case there is no user in DB
			// ignore exception and return NULL for user instead
            }
            return tradingItems;
        }
  
        
	/*
        public User findUserById(String id) {
                TypedQuery<User> query = em.createNamedQuery("findUserById", User.class);
		//TypedQuery<User> query = em.createQuery("findUserById", User.class);
		query.setParameter("email", id);
		User user = null;
		try {
			user = query.getSingleResult();
		} catch (Exception e) {
			// getSingleResult throws NoResultException in case there is no user in DB
			// ignore exception and return NULL for user instead
		}
		return user;
	}
        */
}
