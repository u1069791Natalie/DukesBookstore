/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaeetutorial.dukesbookstore.web.managedbeans;

import java.io.Serializable;
import java.util.List;
import javaeetutorial.dukesbookstore.ejb.OrderBean;
import javaeetutorial.dukesbookstore.ejb.UserItemBean;
import javaeetutorial.dukesbookstore.entity.Order;
import javaeetutorial.dukesbookstore.entity.UserItem;
import javaeetutorial.dukesbookstore.exception.BooksNotFoundException;
import javax.enterprise.context.SessionScoped;
import javax.faces.FacesException;
import javax.inject.Inject;
import javax.inject.Named;


@Named("account")
@SessionScoped
public class AccountBean extends AbstractBean implements Serializable {

    private static final long serialVersionUID = 7829793160454383708L;
    
    private int totalBooks = 0;
    
    @Inject
    OrderBean orderBean;
    
    @Inject
    UserItemBean userItemBean;

    public List<Order> getUserOrders() {
        Integer userId = loggedInUser.getAuthenticatedUserId();
        try {
            return orderBean.getUserOrders(userId);
        } catch (BooksNotFoundException e) {
            throw new FacesException("Exception: " + e);
        }
    }
    

    public List<UserItem> getUserItemsById() {
        Integer userId = loggedInUser.getAuthenticatedUserId();
        try {
            return userItemBean.getUserItemsById(userId);
        } catch (BooksNotFoundException e) {
            throw new FacesException("Exception: " + e);
        }
    }
    
    public List<UserItem> getTradingItemsById() {
        UserItem tradeItem = (UserItem) context().getExternalContext().getSessionMap().get("selected"); 
        Integer userId = loggedInUser.getAuthenticatedUserId();
        try {
            return userItemBean.getTradingItemsById(tradeItem.getUserSaleItemId(), userId);
        } catch (BooksNotFoundException e) {
            throw new FacesException("Exception: " + e);
        }
    }
    
    protected UserItem item() {
        UserItem item;
        item = (UserItem) context().getExternalContext().getRequestMap().get("item");
        return (item);
    }
            
    public String removeItem() {
        UserItem item = item();
        userItemBean.markItemDeleted(item);
        return ("account");
    }
    
    public String tradeItem() {
        UserItem tradeItem = (UserItem) context().getExternalContext().getSessionMap().get("selected"); 
        UserItem item = item();
        userItemBean.tradeItem(tradeItem, item);
        message(null, "ConfirmAdd", new Object[]{item.getTitle()});
        return ("trade");
    }
    
    public String itemDetails() {
        context().getExternalContext().getSessionMap().put("selected", item());

        return ("/userItemDetails");
    }
    
    
}
