/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaeetutorial.dukesbookstore.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;

@Entity
@Table(name = "Orders")
@NamedQueries({@NamedQuery(name = "getLastId", query = "SELECT o FROM Order o "
        + "WHERE o.orderId = (SELECT MAX(o2.orderId) FROM Order o2 "
        + "WHERE o2.userId = :userId AND o2.orderDate = :orderDate)"),
        @NamedQuery(name = "getOrdersByUserId", query = "SELECT o FROM Order o WHERE o.userId = :userId")})

//Query q = em.createQuery ("SELECT m FROM Magazine m WHERE m.price = (SELECT MAX(x.price) FROM Magazine x WHERE m = x AND x.title = 'JDJ')");
//@NamedQuery(name = "listOrders", query = "SELECT o FROM Orders o ORDER BY o.orderDate")
//@NamedQueries({@NamedQuery(name = "getOrderById", query = "SELECT o FROM Orders o WHERE o.OrderId = :myOrderId")})
public class Order implements Serializable {

    private static final long serialVersionUID = 1L;
    
    @Id
    @Column(name="OrderId", nullable=false)
    private Integer orderId;
    @Column(name="UserId", nullable=false)
    private Integer userId;
    @Column(name="OrderDate", nullable=false)
    @Temporal(javax.persistence.TemporalType.DATE)
    private java.util.Date orderDate;
    @Column(name="SalePrice")
    private Double salePrice;
    @Column(name="SaleShipping")
    private Double saleShipping;
    @Column(name="SaleGST")
    private Double saleGST;
    @Column(name="SaleTotal")
    private Double saleTotal;
    @Column(name="NumOfItems")
    private Integer numOfItems;
    @Column(name="SaleType", length=3)
    private String saleType;
    
    public Order() {}

    public Order(Integer userId, java.util.Date orderDate, 
            Double salePrice, Double saleShipping, Double saleGST, 
            Integer numOfItems, String saleType) {
        //this.orderId = orderId;
        this.userId = userId;
        this.orderDate = orderDate;
        this.salePrice = salePrice;
        this.saleShipping = saleShipping;
        this.saleGST = saleGST;
        this.saleTotal = salePrice + saleShipping + saleGST;
        this.numOfItems = numOfItems;
        this.saleType = saleType;
    }

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public java.util.Date getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(java.sql.Date orderDate) {
        this.orderDate = orderDate;
    }

    public Double getSalePrice() {
        return salePrice;
    }

    public void setSalePrice(Double salePrice) {
        this.salePrice = salePrice;
    }

    public Double getSaleShipping() {
        return saleShipping;
    }

    public void setSaleShipping(Double saleShipping) {
        this.saleShipping = saleShipping;
    }

    public Double getSaleGST() {
        return saleGST;
    }

    public void setSaleGST(Double saleGST) {
        this.saleGST = saleGST;
    }

    public Double getSaleTotal() {
        return saleTotal;
    }

    public void setSaleTotal(Double saleTotal) {
        this.saleTotal = saleTotal;
    }

    public Integer getNumOfItems() {
        return numOfItems;
    }

    public void setNumOfItems(Integer numOfItems) {
        this.numOfItems = numOfItems;
    }
    
    public String getSaleType() {
        return saleType;
    }

    public void setSaleType(String saleType) {
        this.saleType = saleType;
    }
    
    
    
}
