package javaeetutorial.dukesbookstore.ejb;

import java.util.List;
import javaeetutorial.dukesbookstore.entity.Order;
import javaeetutorial.dukesbookstore.entity.SaleItem;
import javaeetutorial.dukesbookstore.entity.User;
import javaeetutorial.dukesbookstore.exception.BookNotFoundException;
import javaeetutorial.dukesbookstore.exception.BooksNotFoundException;
import javax.ejb.EJBException;
import javax.ejb.Stateful;
import javax.faces.FacesException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

/**
 * <p>Stateful session bean for the bookstore example.</p>
 */
@Stateful
public class OrderBean {

    //@PersistenceContext(unitName="dukesbookstorePU")
    @PersistenceContext(unitName="DukesBooks")
    private EntityManager em;
    //private Integer newOrderId;
    
    public OrderBean() throws Exception {
    }

    public void createOrder(Integer userId, java.util.Date orderDate, 
            Double salePrice, Double saleShipping, Double saleGST, 
            Integer numOfItems, String saleType) {
        try {
            Order order = new Order(userId, orderDate, salePrice,
                    saleShipping, saleGST, numOfItems, saleType);
            em.persist(order);  
        } catch (Exception ex) {
            throw new EJBException(ex.getMessage());
        }
    }
    
    public List<Order> getOrders() throws BooksNotFoundException {
        try {
            return (List<Order>) em.createNamedQuery("listOrders").getResultList();
        } catch (Exception ex) {
            throw new BooksNotFoundException(
                    "Could not get books: " + ex.getMessage());
        }
    }

    public Order getOrder(Integer orderId) throws BookNotFoundException {
        try {	
            Order requestedOrder = em.find(Order.class, orderId);
            if (requestedOrder == null) {
                throw new BookNotFoundException("Couldn't find order: " + orderId);
            }
            return requestedOrder;

        } catch (BookNotFoundException e) {
            throw new FacesException("Could not convert id: " + e);
        }
    }

    public void createOrderItem(Integer orderId, Integer itemId, Integer quantity,
            Double price, String itemType) {
        try {
            SaleItem item = new SaleItem(orderId, itemId, quantity,
                    price, itemType);
            em.persist(item);
        } catch (Exception ex) {
            throw new EJBException(ex.getMessage());
        }
    }
   
    public Integer getLastId(Integer userId, java.util.Date orderDate) {
                TypedQuery<Order> query = em.createNamedQuery("getLastId", Order.class);
		query.setParameter("userId", userId)
                     .setParameter("orderDate", orderDate);
		Order order = null;
                Integer id = null;
		try {
			order = query.getSingleResult();
                        id = order.getOrderId();
		} catch (Exception e) {
			// getSingleResult throws NoResultException in case there is no user in DB
			// ignore exception and return NULL for user instead
		}
		return id;
    }
   
    public List<Order> getUserOrders(Integer userId) throws BooksNotFoundException {
        try {
            return (List<Order>) em.createNamedQuery("getOrdersByUserId")
                        .setParameter("userId", userId)
                        .getResultList();
        } catch (Exception ex) {
            throw new BooksNotFoundException(
                    "Could not get books: " + ex.getMessage());
        }
    }
    
}

