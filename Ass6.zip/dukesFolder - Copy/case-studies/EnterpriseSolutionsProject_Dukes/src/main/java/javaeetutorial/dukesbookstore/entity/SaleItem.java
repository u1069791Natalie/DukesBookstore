/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaeetutorial.dukesbookstore.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
//import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "SaleItems")
//@NamedQuery(name = "listOrders",
//        query = "SELECT o FROM SaleItems o ORDER BY o.SaleItemId")
public class SaleItem implements Serializable {

    private static final long serialVersionUID = 1L;
    
    @Id
    @Column(name="SaleItemId", nullable=false)
    private Integer saleItemId;
    @Column(name="OrderId", nullable=false)
    private Integer orderId;
    @Column(name="ItemId", nullable=false)
    private Integer itemId;
    @Column(name="Quantity")
    private Integer quantity;
    @Column(name="Price")
    private Double price;
    @Column(name="ItemType", length=10)
    private String itemType;
    
    public SaleItem() {}

    public SaleItem(Integer orderId, Integer itemId, Integer quantity,
            Double price, String itemType) {
        this.orderId = orderId;
        this.itemId = itemId;
        this.quantity = quantity;
        this.price = price;
        this.itemType = itemType;
    }

    public Integer getSaleItemId() {
        return saleItemId;
    }

    //public void setSaleItemId(Integer saleItemId) {
    //    this.saleItemId = saleItemId;
    //}

    public Integer getOrderId() {
        return orderId;
    }

    public void setUserId(Integer orderId) {
        this.orderId = orderId;
    }

    public Integer getItemId() {
        return itemId;
    }

    public void setItemId(Integer itemId) {
        this.itemId = itemId;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public String getItemType() {
        return itemType;
    }

    public void setItemType(String itemType) {
        this.itemType = itemType;
    }
    
    
}
