/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaeetutorial.dukesbookstore.web.managedbeans;

import java.io.Serializable;
import javaeetutorial.dukesbookstore.ejb.UserItemBean;
import javaeetutorial.dukesbookstore.entity.Trade;
import javaeetutorial.dukesbookstore.entity.UserItem;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.faces.event.ComponentSystemEvent;
import javax.inject.Inject;

/**
 *
 * @author m
 */
@Named(value = "userItem")
@RequestScoped
public class UploadItemBean implements Serializable {

    private static final long serialVersionUID = 1L;
    
    @Inject
    private UserItemBean userItemEJB;
    
    @Inject
    private LoginBean loggedInUser;

    private String title;
    private String author;
    private String description;
    private String itemCondition;
    private Integer quantity = 1;
    private Double price = 0.0;
    private String saleType = "S";
    private String itemType = "B";

    public void validateForm(ComponentSystemEvent event) {
		//FacesContext facesContext = FacesContext.getCurrentInstance();
		//UIComponent components = event.getComponent();
    }

    public String Upload() {
        Integer userId = loggedInUser.getAuthenticatedUserId();
	UserItem item = new UserItem(userId, title, author, description, itemCondition,
            quantity, price, saleType, itemType);
	Integer itemId = userItemEJB.createUserItem(item);
        
        if (saleType.equals("T")) {
           Trade tradeItem = new Trade(itemId, userId, "T");
           userItemEJB.createTradeItem(tradeItem);
        }
        
	return "itemConfirmation";
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getItemCondition() {
        return itemCondition;
    }

    public void setItemCondition(String itemCondition) {
        this.itemCondition = itemCondition;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public String getSaleType() {
        return saleType;
    }

    public void setSaleType(String saleType) {
        this.saleType = saleType;
    }

    public String getItemType() {
        return itemType;
    }

    public void setItemType(String itemType) {
        this.itemType = itemType;
    }
    
    
    
}
