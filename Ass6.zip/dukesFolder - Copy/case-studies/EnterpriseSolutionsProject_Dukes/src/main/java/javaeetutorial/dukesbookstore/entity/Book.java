/**
 * Copyright (c) 2014 Oracle and/or its affiliates. All rights reserved.
 *
 * You may not modify, use, reproduce, or distribute this software except in
 * compliance with  the terms of the License at:
 * https://github.com/javaee/tutorial-examples/LICENSE.txt
 */
package javaeetutorial.dukesbookstore.entity;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * <p>Entity class for bookstore example.</p>
 */
@Entity
//@Table(name = "WEB_BOOKSTORE_BOOKS")
@Table(name = "Book")
@NamedQueries({@NamedQuery(name = "findBooks", query = "SELECT b FROM Book b WHERE b.inventory > 0 ORDER BY b.bookId"),
               @NamedQuery(name = "searchBooks", query = "SELECT b FROM Book b WHERE lower(b.title) LIKE :search "
                       + "OR lower(b.firstname) LIKE :search "
                       + "OR lower(b.surname) LIKE :search "
                       + "AND b.inventory > 0")})
public class Book implements Serializable {

    private static final long serialVersionUID = -4146681491856848089L;

    @Id
    @NotNull
    @Column(name = "BookId")
    private Integer bookId;
    @Column(name = "Isbn")
    private String isbn;
    @Column(name = "Surname")
    private String surname;
    @Column(name = "Firstname")
    private String firstname;
    @Basic(optional = false)
    @NotNull
    @Column(name = "Title")
    private String title;
    @Column(name = "Price")
    private Double price;
    @Column(name = "Onsale")
    private Boolean onsale;
    @Column(name = "CalendarYear")
    private Integer calendarYear;
    @Size(max = 100)
    @Column(name = "Description")
    private String description;
    @Column(name = "Inventory")
    private Integer inventory;
    @Column(name = "SubCategoryId")
    private Integer subCategoryId;

    

    public Book() {
    }

    public Book(Integer bookId, String surname, String firstname, String title,
            Double price, Boolean onsale, Integer calendarYear,
            String description, Integer inventory) {
        this.bookId = bookId;
        this.surname = surname;
        this.firstname = firstname;
        this.title = title;
        this.price = price;
        this.onsale = onsale;
        this.calendarYear = calendarYear;
        this.description = description;
        this.inventory = inventory;
    }

    public Book(Integer bookId) {
        this.bookId = bookId;
    }

    public Integer getBookId() {
        return bookId;
    }

    public void setBookId(Integer bookId) {
        this.bookId = bookId;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Boolean getOnsale() {
        return onsale;
    }

    public void setOnsale(Boolean onsale) {
        this.onsale = onsale;
    }

    public Integer getCalendarYear() {
        return calendarYear;
    }

    public void setCalendarYear(Integer calendarYear) {
        this.calendarYear = calendarYear;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getInventory() {
        return inventory;
    }

    public void setInventory(Integer inventory) {
        this.inventory = inventory;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (bookId != null ? bookId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof Book)) {
            return false;
        }
        Book other = (Book) object;
        return this.bookId != null || this.bookId == null 
                //&& other.bookId == null || this.bookId.equals(other.bookId);
                && other.bookId == null || this.bookId == other.bookId;
    }

    @Override
    public String toString() {
        return "bookstore.entities.Book[ bookId=" + bookId + " ]";
    }
}
