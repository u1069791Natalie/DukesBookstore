/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaeetutorial.dukesbookstore.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "UserSaleItems")
@NamedQueries({@NamedQuery(name = "findUserItems", query = "SELECT u FROM UserItem u "
        + "WHERE u.deleted != true AND u.sold = 0 AND u.quantity > 0 ORDER BY u.userSaleItemId"),
@NamedQuery(name = "searchItems", query = "SELECT u FROM UserItem u WHERE lower(u.title) LIKE :search "
    + "OR lower(u.author) LIKE :search AND u.quantity > 0 AND u.deleted != true AND u.sold = 0"),
@NamedQuery(name = "getItemsById", query = "SELECT u FROM UserItem u WHERE u.userId = :userId "
    + "AND u.deleted != true AND u.quantity > 0 AND u.sold = 0"),
@NamedQuery(name = "getLastItemId", query = "SELECT u FROM UserItem u "
        + "WHERE u.userSaleItemId = (SELECT MAX(u2.userSaleItemId) FROM UserItem u2 "
        + "WHERE u2.userId = :userId)")})

public class UserItem implements Serializable {

    private static final long serialVersionUID = 1L;
    
    @Id
    @Column(name="UserSaleItemId", nullable=false)
    private Integer userSaleItemId;
    @Column(name="UserId", nullable=false)
    private Integer userId;
    @Column(name="Title", nullable=false)
    private String title;
    @Column(name="Author", nullable=false)
    private String author;
    @Column(name="Description")
    private String description;
    @Column(name="ItemCondition")
    private String itemCondition;
    @Column(name="Quantity")
    private Integer quantity;
    @Column(name="Price")
    private Double price;
    @Column(name="SaleType")
    private String saleType;
    @Column(name="ItemType")
    private String itemType;
    @Column(name="Sold")
    private Integer sold;
    @Column(name="Deleted")
    private Boolean deleted;
        
    public UserItem() {}

    public UserItem(Integer userId, String title, String author, String description, String itemCondition,
            Integer quantity, Double price, String saleType, String itemType) {
        this.userId = userId;
        this.title = title;
        this.author = author;
        this.description = description;
        this.itemCondition = itemCondition;
        this.quantity = quantity;
        this.price = price;
        this.saleType = saleType;
        this.itemType = itemType;
        this.sold = 0;
        this.deleted = false;
    }

    public Integer getSold() {
        return sold;
    }

    public void setSold(Integer sold) {
        this.sold = sold;
    }
    
    public Boolean getDeleted() {
        return deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }
    
    public Integer getUserSaleItemId() {
        return userSaleItemId;
    }
    
    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {    
        this.userId = userId;
    }
    //public void setUserSaleItemId(Integer userSaleItemId) {
    //    this.userSaleItemId = userSaleItemId;
    //}
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getItemCondition() {
        return itemCondition;
    }

    public void setItemCondition(String itemCondition) {
        this.itemCondition = itemCondition;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public String getSaleType() {
        switch (saleType) {
        case "S":
            return "Sale";
        case "T":
            return "Trade";
        case "A":
            return "Auction";
        default:
            return saleType;
        }
    }

    public void setSaleType(String saleType) {
        this.saleType = saleType;
    }

    public String getItemType() {
        return itemType;
    }

    public void setItemType(String itemType) {
        this.itemType = itemType;
    }


    

    
    
}