/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaeetutorial.dukesbookstore.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;

@Entity
@Table(name = "TradeItems")


@NamedQueries({@NamedQuery(name = "findTradeItems", query = "SELECT t FROM Trade t "
        + "WHERE t.deleted != 1 ORDER BY t.tradeNo"),
    @NamedQuery(name = "getTradeById", query = "SELECT t FROM Trade t WHERE t.tradeId = :itemId "
    + "AND t.deleted != true"),
    @NamedQuery(name = "getTradeItemById", query = "SELECT t FROM Trade t WHERE t.tradeId = :itemId "
    + "AND t.traderId = :userId AND t.deleted != true")})

public class Trade implements Serializable {

    private static final long serialVersionUID = 1L;
    
    @Id
    @Column(name="TradeNo", nullable=false)
    private Integer tradeNo;
    @Column(name="TradeId", nullable=false)
    private Integer tradeId;
    @Column(name="OwnerId", nullable=false)
    private Integer ownerId;
    @Column(name="TradedStatus")
    private String status;
    @Column(name="OfferTimeKey")
    @Temporal(javax.persistence.TemporalType.DATE)
    private java.util.Date offerTimeKey;
    @Column(name="TraderId")
    private Integer traderId;
    @Column(name="ItemId")
    private Integer itemId;
    @Column(name="Deleted")
    private Boolean deleted;
        
    public Trade() {}

    public Trade(Integer tradeId, Integer ownerId, String status) {
        this.tradeId = tradeId;
        this.ownerId = ownerId;
        this.status = status;
        this.deleted = false;
    }

    public Trade(Integer tradeId, Integer ownerId, String status,
            java.util.Date offerTimeKey, Integer traderId, Integer itemId) {
        this.tradeId = tradeId;
        this.ownerId = ownerId;
        this.status = status;
        this.offerTimeKey = offerTimeKey;
        this.traderId = traderId;
        this.itemId = itemId;
        this.deleted = false;
    }
    
    public void setOffer(java.util.Date offerTimeKey, 
            Integer traderId, Integer itemId) {
        this.offerTimeKey = offerTimeKey;
        this.traderId = traderId;
        this.itemId = itemId;
    }

    public Boolean getDeleted() {
        return deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }
    
    public Integer getTradeNo() {
        return tradeNo;
    }

    public Integer getTradeId() {
        return tradeId;
    }

    public Integer getOwnerId() {
        return ownerId;
    }

    public String getStatus() {
        return status;
    }

    public Date getOfferTimeKey() {
        return offerTimeKey;
    }

    public Integer getTraderId() {
        return traderId;
    }

    public Integer getItemId() {
        return itemId;
    }
    
}